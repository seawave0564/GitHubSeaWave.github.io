import java.util.HashMap;
import java.util.Scanner;
public class Bank {
    static int flag=0;
    int RMB;
    int income() {
        HashMap<String,String> user=new HashMap<String,String>();
        user.put("1001","张三");
        user.put("1002","李四");
        user.put("1003","王五");
        HashMap<String,String>pwd=new HashMap<String,String>();
        pwd.put("1001","111");
        pwd.put("1002","222");
        pwd.put("1003","333");
        Scanner sc =new Scanner(System.in);
        System.out.println("请输入银行卡号：");
        String un = sc.next();
        if (pwd.containsKey(un)){
            System.out.println("请输入密码：");
            String pw = sc.next();
            if (pw.equals(pwd.get(un))){
                System.out.println("登录成功！"+"欢迎"+user.get(un)+"先生");
                return 1;
            }else{
                System.out.println("密码错误！请重新输入。");
                return 0;
            }
        }else
            System.out.println("用户名不存在，请重新输入。");
        return 0;
    }
    int Choice(){
        System.out.println("1:存款 2.取款 3.余额 0.退出");
        int in;
        Scanner sc =new Scanner(System.in);
        in = sc.nextInt();
        return in;
    }
    void ck() {
        int ck;
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入存款数额");
        for (int i = 0; ; i++) {
            ck = sc.nextInt();
            if (ck > 0) {
                this.RMB += ck;
                System.out.println("取款成功！");
                return;
            } else {
                System.out.println("输入错误请重新输入!");
            }
        }
    }
    void qk(){
        int qk;
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入取款数额：");
        for (int i = 0; ; i++) {
            qk = sc.nextInt();
            if(this.RMB-qk<0){
                System.out.println("取款数额超过存款！");

            }else if(qk<=0){
                System.out.println("输入不合法，请重新输入！");
            }else {
                this.RMB-=qk;
                System.out.println("取款成功");
                return;
            }
        }
    }
    void ye(){
        System.out.println(this.RMB);
    }
    public static void main(String[] args) {
        int choice;
        System.out.println("欢迎进入网上银行系统!");
        Bank a1 = new Bank();
        a1.RMB=1200;
        while(flag==0){
            flag = a1.income();
        }
        for (; ; ) {
            System.out.println("请输入您要进行的操作类型，按回车键结束");
            choice = a1.Choice();
            switch (choice) {
                case 0:
                    System.out.println("退出系统成功");
                    System.exit(-1);
                case 1:
                    a1.ck();
                    break;
                case 2:
                    a1.qk();
                    break;
                case 3:
                    a1.ye();
                    break;
                default:
                    System.out.println("输入不合法，请重新输入。");
            }
        }
    }
}
